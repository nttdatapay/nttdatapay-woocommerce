<?php
/**
 * Plugin Name: NTT DATA Payment Services
 * Plugin URI: https://www.nttdatapay.com
 * Description: Extends WooCommerce 8 by Adding the NDPS Payment Gateway.
 * Version: 8.2
 * Author: NTT DATA Payment Services
 * Author URI: https://www.nttdatapay.com
 */

// Bail If Accessed Directly
if( ! defined( 'ABSPATH' ) ) { exit; }

// Declare Support For HPOS
add_action( 'before_woocommerce_init', function() {
	if( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility(
			'custom_order_tables', __FILE__, true
		);
	}
} );

// Declare Support For Cart+Checkout Blocks
add_action( 'before_woocommerce_init', function() {
	if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'cart_checkout_blocks', __FILE__, true );
	}
} );

// Plugins Page Link To Settings
add_filter(
	'plugin_action_links_woo-nttdatapay/ccom-ndps-checkout.php',
	function( $links ) {

    $settings = [
		'settings' => sprintf(
			'<a href="%s">%s</a>',
			admin_url( 'admin.php?page=wc-settings&tab=checkout&section=ndpscheckout' ),
			__( 'Settings', 'woocommerce' )
		),
	];

    return array_merge( $settings, $links );

} );

// Require Gateway PHP Class
require_once( 'class.wc_gateway_ndpscheckout.php' );


// Add Gateway To WooCommerce
add_filter( 'woocommerce_payment_gateways', function( $methods ) {
	$methods[] = 'WC_Gateway_NdpsCheckout'; 
	return $methods;
} );

// Blocks Support
add_action( 'woocommerce_blocks_loaded', function() {

	if( class_exists( 'Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType' ) ) {
		require_once( 'includes/class.blocks-checkout.php' );
		add_action(
			'woocommerce_blocks_payment_method_type_registration',
			function( Automattic\WooCommerce\Blocks\Payments\PaymentMethodRegistry $payment_method_registry ) {
				$payment_method_registry->register( new WC_NdpsCheckout_Blocks );
		} );
	}

} );