<?php

class NdpsTransactionRequest
{
    private $login;

    private $password;

    private $productId;

    private $amount;

    private $transactionCurrency;

    private $transactionId;

    private $customerAccount;

    private $customerName;

    private $customerEmailId;

    private $customerMobile;

    private $customerBillingAddress;

    private $transactionUrl;

    private $requestEncryptionKey = "";

    private $responseDecryptionKey = "";

    private $udf1;

    private $udf2;

    private $udf3;

    private $udf4;

    private $udf5;

    public function setRequestEncryptionKey($key){
        $this->requestEncryptionKey = $key;
    }

    public function getRequestEncryptionKey($key){
        return $this->requestEncryptionKey;
    }

    public function setResponseDecryptionKey($key){
        $this->responseDecryptionKey = $key;
    }

    public function getResponseDecryptionKey($key){
        return $this->responseDecryptionKey;
    }

    /**
     * @return the $login
     */
    public function getLogin()
    {
        return $this->login;
    }

    /**
     * @param string $login
     */
    public function setLogin($login)
    {
        $this->login = $login;
    }

    /**
     * @return the $password
     */
    public function getPassword()
    {
        return $this->password;
    }

    /**
     * @param string $password
     */
    public function setPassword($password)
    {
        $this->password = $password;
    }

    /**
     * @return the $productId
     */
    public function getProductId()
    {
        return $this->productId;
    }

    /**
     * @param string $productId
     */
    public function setProductId($productId)
    {
        $this->productId = $productId;
    }

    /**
     * @return the $amount
     */
    public function getAmount()
    {
        return $this->amount;
    }

    /**
     * @param string $amount
     */
    public function setAmount($amount)
    {
        $this->amount = $amount;
    }

    /**
     * @return the $transactionCurrency
     */
    public function getTransactionCurrency()
    {
        return $this->transactionCurrency;
    }

    /**
     * @param string $transactionCurrency
     */
    public function setTransactionCurrency($transactionCurrency)
    {
        $this->transactionCurrency = $transactionCurrency;
    }

    /**
     * @return the $transactionId
     */
    public function getTransactionId()
    {
        return $this->transactionId;
    }

    /**
     * @param string $transactionId
     */
    public function setTransactionId($transactionId)
    {
        $this->transactionId = $transactionId;
    }

    /**
     * @return the $customerAccount
     */
    public function getCustomerAccount()
    {
        return $this->customerAccount;
    }

    /**
     * @param string $customerAccount
     */
    public function setCustomerAccount($customerAccount)
    {
        $this->customerAccount = $customerAccount;
    }

    /**
     * @return the $customerName
     */
    public function getCustomerName()
    {
        return $this->customerName;
    }

    /**
     * @param string $customerName
     */
    public function setCustomerName($customerName)
    {
        $this->customerName = $customerName;
    }

    /**
     * @return the $customerEmailId
     */
    public function getCustomerEmailId()
    {
        return $this->customerEmailId;
    }

    /**
     * @param string $customerEmailId
     */
    public function setCustomerEmailId($customerEmailId)
    {
        $this->customerEmailId = $customerEmailId;
    }

    /**
     * @return the $customerMobile
     */
    public function getCustomerMobile()
    {
        return $this->customerMobile;
    }

    /**
     * @param string $customerMobile
     */
    public function setCustomerMobile($customerMobile)
    {
        $this->customerMobile = $customerMobile;
    }

    /**
     * @return the $udf1
     */
    public function getUdf1()
    {
        return $this->udf1;
    }

    /**
     * @param string $udf1
     */
    public function setUdf1($udf1)
    {
        $this->udf1 = $udf1;
    }

    /**
     * @return the $udf2
     */
    public function getUdf2()
    {
        return $this->udf2;
    }

    /**
     * @param string $udf2
     */
    public function setUdf2($udf2)
    {
        $this->udf2 = $udf2;
    }

    /**
     * @return the $udf3
     */
    public function getUdf3()
    {
        return $this->udf3;
    }

    /**
     * @param string $udf3
     */
    public function setUdf3($udf3)
    {
        $this->udf3 = $udf3;
    }

    /**
     * @return the $udf4
     */
    public function getUdf4()
    {
        return $this->udf4;
    }

    /**
     * @param string $udf4
     */
    public function setUdf4($udf4)
    {
        $this->udf4 = $udf4;
    }

     /**
     * @return the $udf5
     */
    public function getUdf5()
    {
        return $this->udf5;
    }

    /**
     * @param string $udf5
     */
    public function setUdf5($udf5)
    {
        $this->udf5 = $udf5;
    }

    public function getNdpsRequestJsonData() {

        $authAPIRequestJSONArray = array();
        $payInstrumentArray = array();
        $headDetailsArray = array();
        $merchDetailsArray = array();
        $payDetailsArray = array();
        $custDetailsArray = array();
        $extrasArray = array();
        
        $headDetailsArray['version'] = 'OTSv1.1';
        $headDetailsArray['api'] = 'AUTH';
        $headDetailsArray['platform'] = 'FLASH';
        
        $merchDetailsArray['merchId'] = $this->getLogin();
        $merchDetailsArray['userId'] = '';
        $merchDetailsArray['password'] = $this->getPassword();
        $merchDetailsArray['merchTxnId'] = $this->getTransactionId();
        $merchDetailsArray['merchTxnDate'] = date('Y-m-d h:m:s');
        
        $payDetailsArray['amount'] = $this->getAmount();
        $payDetailsArray['product'] = $this->getProductId();
        $payDetailsArray['custAccNo'] = $this->getCustomerAccount();
        $payDetailsArray['txnCurrency'] = $this->getTransactionCurrency();
        
        $custDetailsArray['custEmail'] = strip_tags($this->getCustomerEmailId());
        $custDetailsArray['custMobile'] = strip_tags($this->getCustomerMobile());
        
        $extrasArray['udf1'] = $this->getUdf1();
        $extrasArray['udf2'] = $this->getUdf2();
        $extrasArray['udf3'] = $this->getUdf3();
        $extrasArray['udf4'] = $this->getUdf4();
        $extrasArray["udf5"] = $this->getUdf5();
        
        $payInstrumentArray['headDetails'] = $headDetailsArray;
        $payInstrumentArray['merchDetails'] = $merchDetailsArray;
        $payInstrumentArray['payDetails'] = $payDetailsArray;
        $payInstrumentArray['custDetails'] = $custDetailsArray;
        $payInstrumentArray['extras'] = $extrasArray;
        $authAPIRequestJSONArray['payInstrument'] = $payInstrumentArray;
        
        $requestJsonData = json_encode($authAPIRequestJSONArray, true);

        include_once 'AtomAES.php';
        $atomenc = new AtomAES();
        $encryptedData = $atomenc->encrypt($requestJsonData, $this->requestEncryptionKey, $this->requestEncryptionKey);
        return strtoupper($encryptedData);
    }
}

?>