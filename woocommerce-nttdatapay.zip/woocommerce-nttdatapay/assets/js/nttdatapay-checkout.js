const ndpscheckout_data = window.wc.wcSettings.getSetting('ndpscheckout_data', {});
const ndpscheckout_label = window.wp.htmlEntities.decodeEntities(ndpscheckout_data.title)
	|| window.wp.i18n.__('NTT DATA Payment Services', 'ccom-ndps-checkout');
const ndpscheckout_content = () => {
	return window.wp.htmlEntities.decodeEntities(ndpscheckout_data.description || 'Pay securely via Card/Net Banking/UPI/Wallet via NTT Data Payment Services.');
};
const NdpsCheckout = {
	name: 'ndpscheckout',
	label: ndpscheckout_label,
	content: Object(window.wp.element.createElement)(ndpscheckout_content, null),
	edit: Object(window.wp.element.createElement)(ndpscheckout_content, null),
	canMakePayment: () => true,
	placeOrderButtonLabel: window.wp.i18n.__('Place Order', 'ccom-ndps-checkout'),
	ariaLabel: ndpscheckout_label,
	supports: {
		features: ndpscheckout_data.supports,
	},
};

window.wc.wcBlocksRegistry.registerPaymentMethod(NdpsCheckout);