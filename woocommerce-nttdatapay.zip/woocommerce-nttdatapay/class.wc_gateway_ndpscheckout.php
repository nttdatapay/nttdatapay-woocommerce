<?php

// Bail If Accessed Directly
if( ! defined( 'ABSPATH' ) ) { exit; }
include_once 'includes/ndps-logger.php';
add_action( 'plugins_loaded', 'init_ndps_payment_gateway' );
function init_ndps_payment_gateway() {

	// Bail If Preexists
	if( class_exists( 'WC_Gateway_NdpsCheckout' ) ) {
		return;
	}

	// Payment Gateway Class
	class WC_Gateway_NdpsCheckout extends WC_Payment_Gateway {

        const NTTDATAPAY_WC_FORM_SUBMIT  = 'nttdatapay_wc_form_submit'; // defines the form name

		// Constructor
		public function __construct($hooks = true) {
			$this->has_fields = false;
			$this->id = 'ndpscheckout';
			$this->method_title = __( 'NTT DATA Payment Services', 'ccom-ndps-checkout' );
			$this->method_description = __(
				'Pay securely via Card/Net Banking/UPI/Wallet via NTT Data Payment Services.',
				'ccom-ndps-checkout'
			);
			$this->init_form_fields();
			$this->init_settings();
			$this->title = __( 'NTT DATA Payment Services', 'ccom-ndps-checkout' );
			$this->description =  __(
				'Pay securely via Card/Net Banking/UPI/Wallet via NTT Data Payment Services.',
				'ccom-ndps-checkout'
			);
			add_action(
				'woocommerce_update_options_payment_gateways_' . $this->id,
				[ $this, 'process_admin_options' ]
			);

			if ($hooks)
            {
                $this->initHooks();
            }

		}

		private function initHooks() {
			add_action('woocommerce_receipt_' . $this->id, array($this, 'receipt_page'));
			add_action('woocommerce_api_' . $this->id, array($this, 'check_nttdatapay_response'));
		}

		// Settings Fields
		public function init_form_fields() {
			$this->form_fields = include("nttdatapay-settings.php");
		}

		function receipt_page($orderId)
        {
		   foreach (debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS) as $value)
            {
                if ($value['function'] === 'output' and
                    stripos($value['file'], 'themes/divi') !== false and
                    basename($value['file'], ".php") !== 'CheckoutPaymentInfo')
                {
                    return;
                }
            }

            echo $this->generate_nttdatapay_form($orderId);
        }

		protected function getNttdatapayPaymentParams($order, $orderId)
        {
            $getWebhookFlag =  get_option('webhook_enable_flag');
            $time = time();
            if (empty($getWebhookFlag) == false)
            {
                if ($getWebhookFlag + 86400 < time())
                {
                    // $this->autoEnableWebhook();
                }
            }
            else
            {
                update_option('webhook_enable_flag', $time);
                // $this->autoEnableWebhook();
            }

            return [
                'order_id'  =>  base64_decode($_GET['token'])
            ];
        }

		public function generate_nttdatapay_form($orderId)
        {
			$order = wc_get_order($orderId);

            try
            {
                $params = $this->getNttdatapayPaymentParams($order, $orderId);
            }
            catch (Exception $e)
            {
                return $e->getMessage();
            } 

            $checkoutArgs = $this->getCheckoutArguments($order, $params);

            $html = '<p>'.__('Thank you for your order, please click the button below to pay with NTT DATA Payment Services.', $this->id).'</p>';

            $html .= $this->generateOrderForm($checkoutArgs, $orderId);

            return $html;
        }

		 /**
         * Returns array of checkout params
         */
        private function getCheckoutArguments($order, $params)
        {
            $args = $this->getDefaultCheckoutArguments($order);

            $args = array_merge($args, $params);

            return $args;
        }

		/**
         * default parameters passed to checkout
         * @param  WC_Order $order WC Order
         * @return array checkout params
         */
        public function getDefaultCheckoutArguments($order)
        {
			global $woocommerce;
            $orderId = $order->get_order_number();
            $wcOrderId = $order->get_id();
			
			$atomTokenId = "";
			if (isset($_GET['token'])) {
				$atomTokenId = base64_decode($_GET['token']);
			}

            $productinfo = "Order $orderId";
		
            return array(
                'name'         => html_entity_decode(get_bloginfo('name'), ENT_QUOTES),
                'description'  => $productinfo,
                'order_id'     => $atomTokenId,
                'prefill'      => $this->getCustomerInfo($order)
            );
        }

		public function getCustomerInfo($order)
        {
            if (version_compare(WOOCOMMERCE_VERSION, '2.7.0', '>='))
            {
                $args = array(
                    'name'    => $order->get_billing_first_name() . ' ' . $order->get_billing_last_name(),
                    'email'   => $order->get_billing_email(),
                    'contact' => $order->get_billing_phone(),
					'merchId' => $this->settings['login_id']
                );
            }
            else
            {
                $args = array(
                    'name'    => $order->billing_first_name . ' ' . $order->billing_last_name,
                    'email'   => $order->billing_email,
                    'contact' => $order->billing_phone,
					'merchId' => $this->settings['login_id']
                );
            }

            return $args;
        }

		 /**
         * Generates the order form
         **/
        function generateOrderForm($data, $orderId)
        {
            $redirectUrl = $this->getRedirectUrl($orderId);
            $data['cancel_url'] = wc_get_checkout_url();
            $data['return_url'] = $redirectUrl;

            $this->enqueueCheckoutScripts($data);

            return <<<EOT
					<form name='nttdatapayform' action="$redirectUrl" method="POST">
						<!-- This distinguishes all our various wordpress plugins -->
						<input type="hidden" name="nttdatapay_wc_form_submit" value="1">
					</form>
					<p>
						<button id="btn-nttdatapay">Pay Now</button>
						<button id="btn-nttdatapay-cancel" onclick="document.nttdatapayform.submit()">Cancel</button>
					</p>
					EOT;
        }

		/**
         * Returns redirect URL post payment processing
         * @return string redirect URL
         */
        private function getRedirectUrl($orderId)
        {
            $order = wc_get_order($orderId);

            $query = [
                'wc-api' => $this->id,
                'order_key' => $order->get_order_key(),
            ];

            return add_query_arg($query, trailingslashit(get_home_url()));
        }


		public function enqueueCheckoutScripts($data)
        {
                // calling js code for 
                wp_register_script('nttdatapay_wc_script', plugin_dir_url(__FILE__)  . 'script.js',
                    array('nttdatapay_checkout'));

                    ndpsLogInfo("cdn checkout url: ". $this->settings['ndps_cdn_link']."?v=".time());

                wp_register_script('nttdatapay_checkout',
                    $this->settings['ndps_cdn_link'].'?v='.time(),
                    null, null);

				wp_localize_script('nttdatapay_wc_script',
					'nttdatapay_wc_checkout_vars',
					$data
				);
	
				wp_enqueue_script('nttdatapay_wc_script');	
        
        }

		// WooCommerce Order Submitted
		public function process_payment( $order_id ) {

            ndpsLogInfo("order id: ".$order_id);

			// Get Customer And Order
			$customer = WC()->session->get( 'customer' );
			$order = wc_get_order( $order_id );

			// Set Payent Pending Status
			$order->update_status(
				'pending', __( 'Awaiting payment', 'woocommerce' )
			);

			$customer_name = substr(trim((html_entity_decode( $order->billing_first_name ." ".$order->billing_last_name, ENT_QUOTES, 'UTF-8'))), 0, 20)."<br><br>";
			$customer_email_id = substr($order->billing_email, 0, 75)."<br><br>";
			$customer_phone_number = substr(html_entity_decode($order->billing_phone, ENT_QUOTES, 'UTF-8'), 0, 20)."<br><br>";
			
			include 'includes/NdpsTransactionRequest.php';
			$ndpstransactionRequest = new NdpsTransactionRequest();

			// //Setting all values here
			$ndpstransactionRequest->setLogin($this->settings['login_id']);
			$ndpstransactionRequest->setPassword($this->settings['password']);
			$ndpstransactionRequest->setProductId($this->settings['ndps_prod_id']);
			$ndpstransactionRequest->setAmount($order->get_total());
			$ndpstransactionRequest->setTransactionCurrency($order->currency);
			$ndpstransactionRequest->setTransactionId($order->id);
			$ndpstransactionRequest->setCustomerName($customer_name);
			$ndpstransactionRequest->setCustomerEmailId($customer_email_id);
			$ndpstransactionRequest->setCustomerMobile($customer_phone_number);
			$ndpstransactionRequest->setCustomerAccount("639827");
			$ndpstransactionRequest->setRequestEncryptionKey($this->settings['req_enc_key']);
			$ndpstransactionRequest->setResponseDecryptionKey($this->settings['res_enc_key']);
			$ndpstransactionRequest->setUdf1("");
			$ndpstransactionRequest->setUdf2("");
			$ndpstransactionRequest->setUdf3("");
			$ndpstransactionRequest->setUdf4("");
			$ndpstransactionRequest->setUdf5("");
			$encrypted_request = $ndpstransactionRequest->getNdpsRequestJsonData();

			$curl = curl_init();

			ndpsLogInfo("NDPS AUTH API encrypted request: ".$encrypted_request);
			ndpsLogInfo("NDPS AUTH API URL: ".$this->settings['ndps_auth_api_url']);

			curl_setopt_array($curl, array(
				CURLOPT_URL => $this->settings['ndps_auth_api_url'],
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_ENCODING => "",
				CURLOPT_MAXREDIRS => 10,
				CURLOPT_TIMEOUT => 0,
				CURLOPT_FOLLOWLOCATION => true,
				CURLOPT_SSL_VERIFYHOST => 2,
				CURLOPT_SSL_VERIFYPEER => 1,
				CURLOPT_CAINFO => dirname(__FILE__) . DIRECTORY_SEPARATOR . "lib/cacert.pem",
				CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				CURLOPT_CUSTOMREQUEST => "POST",
				CURLOPT_POSTFIELDS => "encData=".$encrypted_request."&merchId=".$this->settings['login_id'],
				CURLOPT_HTTPHEADER => array(
				  "Content-Type: application/x-www-form-urlencoded"
				),
			  ));

              $atomTokenId = null;
			 
			  $response = curl_exec($curl);
			  ndpsLogInfo("NDPS AUTH API response: ".$response);
			  $getresp = explode("&", $response);
			  $encresp = substr($getresp[1], strpos($getresp[1], "=") + 1);       
			
			  $atomenc = new AtomAES();
			  $decData = $atomenc->decrypt($encresp, $this->settings['res_enc_key'], $this->settings['res_enc_key']);
		  	
			  if(curl_errno($curl)) {
				  $error_msg = curl_error($curl);
				  $atomTokenId = null;
				  ndpsLogError("NDPS AUTH API cURL error: ".$error_msg);
			  }      
				
			  curl_close($curl);
		  
			  $res = json_decode($decData, true);   
		  
			  if($res){
				if($res['responseDetails']['txnStatusCode'] == 'OTS0000'){
				  $atomTokenId = $res['atomTokenId'];
                }else{
				   $atomTokenId = null;
				}
			  }

			  if($atomTokenId == null){
				ndpsLogError("NDPS AUTH API atomTokenId generation failed!. Please check your JSON request data, AUTH API URL, etc. : ".$res);
			  }else{
				ndpsLogInfo("NDPS AUTH API generated atomTokenId: ".$atomTokenId);
                global $woocommerce;
                $orderKey = $order->order_key;
    
                $order->add_order_note(
                    __(
                        'Redirected to Ndps Checkout.',
                        'ccom-ndps-checkout'
                    )
                );
                
                if (version_compare(WOOCOMMERCE_VERSION, '2.1', '>='))
                {
                    return [
                        'result' => 'success',
                        'redirect' => add_query_arg('token', base64_encode($atomTokenId),
                        add_query_arg('key', $orderKey, $order->get_checkout_payment_url(true)))
                    ];
                }
                else if (version_compare(WOOCOMMERCE_VERSION, '2.0.0', '>='))
                {
                    return [
                        'result' => 'success',
                        'redirect' => add_query_arg('order', $order->id,
                                    add_query_arg('key', $orderKey, $order->get_checkout_payment_url(true)))
                    ];
                }
                else
                {
                     return [
                        'result' => 'success',
                        'redirect' => add_query_arg('order', $order->id,
                                    add_query_arg('key', $orderKey, get_permalink(get_option('woocommerce_pay_page_id'))))
                    ];
                }
			  }

		} // End Process Payment Function


		 /**
         * Check for valid nttdatapay server callback
         * Called once payment is completed using redirect method
         */
        // getting response from nttdatapay aipay payments
        function check_nttdatapay_response()
        {
            if($_REQUEST['wc-api'] == $this->id){
                global $woocommerce, $post;
                global $wpdb, $woocommerce;

                $get_order_id = null;
                $payment_status = null;                

                include_once "includes/AtomAES.php";
                $atomenc = new AtomAES();
    
                // handing in case user cancelling the payment
                if(isset($_POST[self::NTTDATAPAY_WC_FORM_SUBMIT]) && $_POST[self::NTTDATAPAY_WC_FORM_SUBMIT] ==1)
                {
                    $error = 'Customer cancelled the payment';
                    wc_add_notice( __( $error , 'ndpscheckout' ), 'error' );
                    wp_redirect(wc_get_checkout_url());
                }
                else
                {

                $enc_data = $_POST['encData'];
                $decrypted = $atomenc->decrypt($enc_data, $this->settings['res_enc_key'], $this->settings['res_enc_key']);
                $responseParams = json_decode($decrypted, true);

                ndpsLogInfo("decrypted response: ".$decrypted);
    
              // new response      
              if (isset($_POST['upiIntentResponse'])) 
              {
                ndpsLogInfo("UPI Intent response received");
                $get_order_id = $responseParams['payInstrument'][0]['merchDetails']['merchTxnId'];
                $payment_status = $responseParams['payInstrument'][0]['responseDetails']['statusCode'];
              } else {
                $get_order_id = $responseParams['payInstrument']['merchDetails']['merchTxnId'];
                $payment_status = $responseParams['payInstrument']['responseDetails']['statusCode'];
            }

            ndpsLogInfo("get_order_id: ".$get_order_id);
            
            $order = new WC_Order( $get_order_id );
               
            if($payment_status === 'OTS0000') {
                ndpsLogInfo("payment completed");
                $order->add_order_note(
                    __(
                        'Payment successful.',
                        'ccom-ndps-checkout'
                    )
                );
                $order->payment_complete('completed');
                $woocommerce->cart->empty_cart();
                wp_redirect($this->get_return_url( $order));
            } else if($payment_status === 'OTS0551') {
                ndpsLogInfo("payment pending: ".$payment_status);
                $order->add_order_note(
                    __(
                        'Payment pending. Challan generated successfully.',
                        'ccom-ndps-checkout'
                    )
                );
                $order_status = 'on-hold';
                $order->update_status( $order_status );
                $woocommerce->cart->empty_cart();
                wp_redirect($this->get_return_url( $order));
            }
            else{
                ndpsLogInfo("payment failed: ".$payment_status);
                $order->add_order_note(
                    __(
                        'Payment failed.',
                        'ccom-ndps-checkout'
                    )
                );
                $order_status = 'failed';
                $order->update_status( $order_status );
                wc_add_notice( __( 'payment failed.', 'ndpscheckout' ), 'error' );
                wp_safe_redirect( wc_get_checkout_url() );
            }

         }
  
        }   
  
        }

	} // End Payment Gateway Class

}