<?php 
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
return array(
    'enabled' => array(
        'title'   => __( 'Enable/Disable', 'woocommerce' ),
        'type'    => 'checkbox',
        'label'   => 'Enable NDPS Checkout',
        'default' => 'yes',
    ),
    'enable_ndps_debug_mode' => array(
        'title'       => __('Activate debug mode'),
        'type'        => 'checkbox',
        'description' => 'When debug mode is active, API logs and errors are collected and stored in your Woocommerce dashboard. It is recommended to keep this activated.',
        'label'       => __('Enable debug mode'),
        'default'     => 'yes',
    ),
    'ndps_auth_api_url' => array(
        'title'          => __('AUTH API URL', 'wc_gateway_atom'),
        'type'           => 'text',
        'description'    => __('Will be provided by Atom Paynetz Team after production movement', 'wc_gateway_atom'),
        'desc_tip'       => true
    ),
    'ndps_cdn_link' => array(
        'title'          => __('NDPS AIPAY JS CDN Link', 'wc_gateway_atom'),
        'type'           => 'text',
        'description'    => __('Will be provided by Atom Paynetz Team', 'wc_gateway_atom'),
        'desc_tip'       => true
    ),
    'login_id' => array(
        'title'          => __('Merchant Id', 'wc_gateway_atom'),
        'type'           => 'text',
        'description'    => __('As provided by Atom Paynetz Team', 'wc_gateway_atom'),
        'desc_tip'       => true
    ),
    'password' => array(
        'title'          => __('Password', 'wc_gateway_atom'),
        'type'           => 'password',
        'description'    => __('As provided by Atom Paynetz Team', 'wc_gateway_atom'),
        'desc_tip'       => true
    ),
    'ndps_prod_id' => array(
        'title'          => __('Product ID', 'wc_gateway_atom'),
        'type'           => 'text',
        'description'    =>  __('Will be provided by Atom Paynetz Team after production movement', 'wc_gateway_atom'),
        'desc_tip'       => true
    ),
    'req_enc_key'  => array(
        'title'          => __('Request Encypriton Key', 'wc_gateway_atom'),
        'type'           => 'text',
        'description'    =>  __('Request Encypriton Key, provided by Atom', 'wc_gateway_atom'),
        'desc_tip'       => true
    ),
    'req_salt_key' => array(
        'title'         => __('Request Salt Key', 'wc_gateway_atom'),
        'type'          => 'text',
        'description'   =>  __('Request Salt Key, provided by Atom', 'wc_gateway_atom'),
        'desc_tip'      => true
    ),
    'res_enc_key'  => array(
        'title'         => __('Response Encypriton Key', 'wc_gateway_atom'),
        'type'          => 'text',
        'description'   =>  __('Response Encypriton Key, provided by Atom', 'wc_gateway_atom'),
        'desc_tip'      => true
    ),
    'res_salt_key' => array(
        'title'         => __('Response Salt Key', 'wc_gateway_atom'),
        'type'          => 'text',
        'description'   =>  __('Response Salt Key, provided by Atom', 'wc_gateway_atom'),
        'desc_tip'      => true
    ),
);