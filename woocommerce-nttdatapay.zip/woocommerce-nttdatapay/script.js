(function () {
    var data = nttdatapay_wc_checkout_vars;
    // return;
    // if (data === 'checkoutForm' || data[0] === 'checkoutForm') {
    //     document.getElementById("checkoutForm").submit();
    // } else if (data === 'routeAnalyticsForm') {
    //     document.getElementById("routeAnalyticsForm").submit();
    // } else {

        var setDisabled = function (id, state) {
            if (typeof state === 'undefined') {
                state = true;
            }
            var elem = document.getElementById(id);
            if (state === false) {
                elem.removeAttribute('disabled');
            } else {
                elem.setAttribute('disabled', state);
            }
        };

        // Payment was closed without handler getting called
        // data.modal = {
        //     ondismiss: function () {
        //         setDisabled('btn-nttdatapay', false);
        //     },
        // };

        window.addEventListener('message', ({ data }) => {
            if (data === "cancelTransaction") {
                setDisabled('btn-nttdatapay', false);
                document.nttdatapayform.submit();
            }
        });

        // global method
        function openAipay() {
            // Disable the pay button
            setDisabled('btn-nttdatapay');
            const options = {
                "atomTokenId": data.order_id,
                "merchId": data.prefill.merchId,
                "custEmail": data.prefill.email,
                "custMobile": data.prefill.contact,
                "returnUrl": data.return_url
            };
            console.table(options);
            let atom = new AtomPaynetz(options, 'uat');
        }

        function addEvent(element, evnt, funct) {
            if (element.attachEvent) {
                return element.attachEvent('on' + evnt, funct);
            } else return element.addEventListener(evnt, funct, false);
        }

        if (document.readyState === 'complete') {
            addEvent(document.getElementById('btn-nttdatapay'), 'click', openAipay);
            openAipay();
        } else {
            document.addEventListener('DOMContentLoaded', function () {
                addEvent(document.getElementById('btn-nttdatapay'), 'click', openAipay);
                openAipay();
            });
        }
    // }
})();
